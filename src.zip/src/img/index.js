const IMAGES = {
    sky:require('./sky.jpg').default,
    fondo1:require('./fondo1.jpg').default,
    fondo2:require('./fondo2.jpg').default,
    fondo3:require('./fondo3.jpg').default,
    bb8:require('./bb8.png').default,
    starWars:require('./starWars.png').default,
}

export default IMAGES;